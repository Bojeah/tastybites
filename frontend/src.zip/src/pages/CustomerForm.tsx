import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { createCustomer, updateCustomer, getCustomer } from "../api/client";

type CustomerFormType = {
  first_name: string;
  surname: string;
  middle_name: string;
  dob: string;
  address: string;
  registration_date: string;
  matric_no: boolean;      // ← match backend
};

export default function CustomerForm() {
  const { id } = useParams<{ id: string }>();
  const isEdit = Boolean(id);
  const navigate = useNavigate();

  const [form, setForm] = useState<CustomerFormType>({
    first_name: "",
    surname: "",
    middle_name: "",
    dob: "",
    address: "",
    registration_date: "",
    matric_no: true,        // ← default
  });

  useEffect(() => {
    if (id) {
      getCustomer(+id).then(data => {
        setForm({
          ...data,
          dob: data.dob.slice(0, 10),
          registration_date: data.registration_date.slice(0, 10),
        });
      });
    }
  }, [id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isEdit) await updateCustomer(+id!, form);
    else await createCustomer(form);
    navigate("/");
  };

  return (
    <div className="p-6 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">{isEdit ? "Edit" : "New"} Customer</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        {[
          "first_name",
          "surname",
          "middle_name",
          "dob",
          "address",
          "registration_date",
        ].map(field => (
          <input
            key={field}
            name={field}
            type={field==="dob" || field.includes("date") ? "date" : "text"}
            value={form[field as keyof CustomerFormType] as string}
            onChange={handleChange}
            placeholder={field.replace(/_/g, " ")}
            className="w-full p-2 border rounded"
            required={field !== "middle_name"}
          />
        ))}

        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            name="matric_no"           // ← use correct name
            checked={form.matric_no}
            onChange={handleChange}
          />
          Matriculated
        </label>

        <button className="bg-blue-600 text-white px-4 py-2 rounded">
          {isEdit ? "Update" : "Create"}
        </button>
      </form>
    </div>
  );
}
