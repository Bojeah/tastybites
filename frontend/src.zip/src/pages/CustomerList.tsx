//customerList.tsx
import { useEffect, useState } from "react";
import { fetchCustomers, deleteCustomer } from "../api/client";
import { Customer } from "../types";
import { Link } from "react-router-dom";

export default function CustomerList() {
  const [customers, setCustomers] = useState<Customer[]>([]);

  useEffect(() => {
    fetchCustomers().then(setCustomers);
  }, []);

  const handleDelete = async (id: number) => {
    await deleteCustomer(id);
    setCustomers(customers.filter(c => c.id !== id));
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Customers</h1>
      <Link to="/new" className="bg-blue-500 text-white px-4 py-2 rounded">Add Customer</Link>
      <ul className="mt-6 space-y-3">
        {customers.map(c => (
          <li key={c.id} className="p-4 bg-gray-100 rounded flex justify-between items-center">
            <Link to={`/customer/${c.id}`} className="font-medium">
              {c.first_name} {c.surname}
            </Link>
            <button
              onClick={() => handleDelete(c.id)}
              className="bg-red-500 text-white px-3 py-1 rounded"
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
