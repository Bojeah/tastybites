//customerdetail.tsx

import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { getCustomer } from "../api/client";
import { Customer } from "../types";

export default function CustomerDetail() {
  const { id } = useParams<{ id: string }>();
  const [customer, setCustomer] = useState<Customer | null>(null);

  useEffect(() => {
    if (id) getCustomer(Number(id)).then(setCustomer);
  }, [id]);

  if (!customer) return <p className="p-4">Loading...</p>;

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-2xl font-bold">{customer.first_name} {customer.surname}</h1>
      <p><strong>DOB:</strong> {customer.dob}</p>
      <p><strong>Address:</strong> {customer.address}</p>
      <p><strong>Registered:</strong> {customer.registration_date}</p>

      <Link to={`/edit/${customer.id}`} className="bg-yellow-500 text-white px-4 py-2 rounded">
        Edit Customer
      </Link>

      <div className="mt-6">
        <h2 className="text-xl font-semibold mb-2">Orders</h2>
        {customer.orders.length === 0 ? (
          <p>No orders yet.</p>
        ) : (
          <ul className="space-y-2">
            {customer.orders.map(order => (
              <li key={order.id} className="p-3 bg-gray-100 rounded">
                <p><strong>Item:</strong> {order.menu_item}</p>
                <p><strong>Date:</strong> {order.order_date}</p>
                <p><strong>Payment:</strong> {order.payment_method}</p>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
