const API_URL = "http://localhost:8000";

export async function fetchCustomers() {
  const res = await fetch(`${API_URL}/customers/`);
  return res.json();
}

export async function getCustomer(id: number) {
  const res = await fetch(`${API_URL}/customers/${id}`);
  return res.json();
}

export async function createCustomer(data: unknown) {
  const res = await fetch(`${API_URL}/customers/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function updateCustomer(id: number, data: unknown) {
  const res = await fetch(`${API_URL}/customers/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function deleteCustomer(id: number) {
  await fetch(`${API_URL}/customers/${id}`, { method: "DELETE" });
}
