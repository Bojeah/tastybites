import { MenuItemType } from "../types";

interface Props {
  item: MenuItemType;
  onAdd: (item: MenuItemType) => void;
}

export default function MenuItem({ item, onAdd }: Props) {
  return (
    <div className="border rounded shadow p-4 flex flex-col items-center">
      {item.image && <img src={item.image} alt={item.name} className="h-32 object-cover rounded mb-2" />}
      <h3 className="font-bold text-lg">{item.name}</h3>
      <p className="text-gray-600 mb-2">{item.description}</p>
      <div className="font-semibold mb-2">${item.price.toFixed(2)}</div>
      <button
        className="bg-orange-500 text-white px-3 py-1 rounded hover:bg-orange-600"
        onClick={() => onAdd(item)}
      >Add to Cart</button>
    </div>
  );
}