import { Link, useNavigate } from "react-router-dom";

interface NavbarProps {
  isAuthenticated: boolean;
  onLogout: () => void;
}

export default function Navbar({ isAuthenticated, onLogout }: NavbarProps) {
  const navigate = useNavigate();

  return (
    <nav className="bg-orange-500 text-white px-4 py-3 flex items-center justify-between">
      <div className="font-bold text-2xl">
        <Link to="/">TastyBites</Link>
      </div>
      <div className="space-x-4">
        <Link to="/menu" className="hover:underline">Menu</Link>
        <Link to="/cart" className="hover:underline">Cart</Link>
        {isAuthenticated && <Link to="/orders" className="hover:underline">Orders</Link>}
        {!isAuthenticated ? (
          <Link to="/login" className="hover:underline">Login</Link>
        ) : (
          <button onClick={() => {onLogout(); navigate("/login")}} className="hover:underline">Logout</button>
        )}
      </div>
    </nav>
  );
}