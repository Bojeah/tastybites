import { Routes, Route, Link } from "react-router-dom";
import CustomerList from "./pages/CustomerList";
import CustomerDetail from "./pages/CustomerDetail";
import CustomerForm from "./pages/CustomerForm";

import './index.css'; 

function App() {
  return (
    <>
      <nav className="bg-blue-600 p-4 text-white">
        <div className="container mx-auto flex justify-between">
          <Link to="/" className="font-bold text-xl">CustomerApp</Link>
          <Link to="/new" className="hover:underline">Add Customer</Link>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<CustomerList />} />
        <Route path="/new" element={<CustomerForm />} />
        <Route path="/customer/:id" element={<CustomerDetail />} />
        <Route path="/edit/:id" element={<CustomerForm />} />
      </Routes>
    </>
  );
}

export default App;